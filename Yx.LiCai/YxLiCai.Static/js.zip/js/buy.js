/*!
 * @description:buy
 *
 */

define('buy',['jquery','gxdialog','fastclick'],function(require, exports, module) {

	var $ = jQuery = require("jquery");//jquery库
	var FastClick = require("fastclick");
	var gxdialog = require("gxdialog");

	//FastClick.attach(document.body);


	$.gxDialog.defaults.background = '#000';



	$('#ok-buy').on('click', function(){
		$.gxDialog({
			title: '',
			width: 280,
			info: document.getElementById('J_buyPwd')
		});
	});

	$('#ok-pwd').on('click', function(){
		$.gxDialog({
			title: '',
			width: 280,
			info: document.getElementById('J_buyPwd')
		});
	});

	$('#ok-bank').on('click', function(){
		$.gxDialog({
			title: '',
			width: 280,
			info: document.getElementById('selectBank')
		});
	});


	$('#dealPassword').on('click', function(){
		$.gxDialog({
			title: '',
			width: 280,
			info: document.getElementById('J_buyPwd')
		});
	});

	$('#ok-get').on('click', function(){
		$.gxDialog({
			title: '',
			width: 280,
			info: document.getElementById('J_get')
		});
	});


	//银行卡选择
	var $bankSelect = $('.J_selectBank'),
		$bankInfor = $('#J_bankInfor');
	$bankInfor.on('click', function(){
		$.gxDialog({
			title: '',
			width: 280,
			closeBtn: false,
			info: document.getElementById('selectBank')
		});
	});

	$bankSelect.on('click', 'input[type=radio]', function(event) {
		event.preventDefault();
		var _this = $(this),
			bankLogo = _this.parent('li').find('img').attr('src'),
			bankName = _this.parent('li').find('p>b').html();
		$bankInfor.find('img').show().attr('src', bankLogo);
		$bankInfor.find('span').show().text(bankName)
		_this.addClass('checked');
		_this.parents('li').siblings('li').children('input').removeClass('checked');
		$.gxDialog.close();
	});








});

seajs.use('buy');
