/*!
 *忘记密码跳页
 *
 */

define('forget_pwd', ['jquery', 'gxdialog', 'jcookie'], function (require, exports, module) {

    var $ = jQuery = require("jquery");//jquery库 
    var gxdialog = require("gxdialog");
    var jcookie = require("jcookie");

    $.gxDialog.defaults.background = '#000';


    //有确认按钮的弹出
    function alertDialog(v) {
        $.gxDialog({
            title: '',
            width: 280,
            closeBtn: false,
            info: '<div class="pop-box"><p class="warning-color">' + v + '</p></div>',
            ok: function () { }
        });
    }

    //function alertDialog(v) {
    //    $.gxDialog({
    //        title: '',
    //        // width: 280,
    //        info: v
    //    });
    //}
    ////start
    ////验证码标识
   var floagCode = false;
    //var InterValObj; //timer变量，控制时间
    //var count = 60; //间隔函数，1秒执行
    //var curCount;//当前剩余秒数
    //var ecount = 60;
    //var ecurCount;
    //var eInterValObj;   
    //if (dianhua != "")
    //{ sendMessage(); }
    //$("#repNewMsg").click(function () {
    //    sendMessage();
    //});

    ////发送手机验证码
    //function sendMessage() {
    //    $("#repOld").show();
    //    $("#repNew").hide();
    //    curCount = count;
    //    InterValObj = window.setInterval(SetRemainTime, 1000); //启动计时器，1秒执行一次

    //    $.ajax({
    //        type: "POST",
    //        async: false,
    //        url: "/Login/SendValidateCode",
    //        data: { account: dianhua },
    //        success: function (data) {
    //            if (!data) {
    //                alertDialog("发送失败");
    //            }
    //        },
    //        error: function (XMLHttpRequest, textStatus, errorThrown) {
    //        },
    //    });
    //}
    ////timer处理函数
    //function SetRemainTime() {
    //    if (curCount == 1) {
    //        window.clearInterval(InterValObj);//停止计时器
    //        $("#repOld").hide();
    //        $("#repNew").show();
    //    }
    //    else {
    //        curCount--;
    //        $("#TimeMove").html(curCount);
    //    }
    //}

    window.onload = firstLoad;


    var time = $.cookie("time");
    //if (time != null) {
    //    times();
    //}

    $("#repNewMsg").on("click", function (e) {
        $.cookie("time", 60);
        Round();
    })

    function firstLoad() {
        if (time != null) {
            time = parseInt(time) + 1;
            times();
            //return;
        }
        else {
            $.cookie("time", 60);
            Round();
        }
    }

    function Round() {
        sendMessage();
        times();
    }

    function times() {
        var ss = time - 1;
        if (ss == -1) {
            return false;
        }
        $.cookie("time", ss);
        time = $.cookie("time");

        $("#repNewMsg").off();
        $("#repNewMsg").css("background", "#dddddd");

        var wait = "剩余时间(" + time + ")";
        $("#repNewMsg").html(wait);

        window.setTimeout(times, 1000);

        if (ss <= 0) {
            $.cookie("time", null);
            $("#repNewMsg").html("再次获取验证码");
            $("#repNewMsg").css("background", "#00b7ee");
            $("#repNewMsg").on("click", function (e) {
                $.cookie("time", 60);
                Round();
            })
            return false;
        }
    }

    //发送手机验证码
    function sendMessage() {

        $.ajax({
            type: "POST",
            async: false,
            url: "/Login/SendValidateCode",
            data: { account: dianhua },
            success: function (data) {
                if (!data) {
                    alertDialog("发送失败");
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
            },
        });
    }
    $("#phoneCode").blur(function () {
        if ($("#phoneCode").val() == "") {
            $("#phoneCode").attr("placeholder", "机器人才不会输验证码");
            floagCode = false;
        } else {
            $.ajax({
                type: "POST",
                async: false,
                url: "/Login/CheckUserCode",
                data: { Code: $("#phoneCode").val().replace(/[ ]/g, ""), Phone: dianhua },
                success: function (data) {
                    if (data == "true") {
                        floagCode = true;
                    } else { floagCode = false; }
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                },
            });
        }
    });
    //下一步按钮
    $("#btnNextok").click(function () {
        if ($("#phoneCode").val() == "") { alertDialog("请输入验证码"); return; }
        if (!floagCode) { alertDialog("验证码输入有误，请重新输入"); return; }
        window.location.href = "/Login/setting_pwd?phone=" + dianhua;
    });

    $("#phoneCode").keyup(function () {
        var num = strlen($("#phoneCode").val().replace(/[ ]/g, ""));
        if (num == 6) { $("#btnNext").hide(); $("#btnNextok").show(); } else { $("#btnNext").show(); $("#btnNextok").hide(); }
    });
    function strlen(str) {
        var len = 0;
        for (var i = 0; i < str.length; i++) {
            var c = str.charCodeAt(i);
            //单字节加1 
            if ((c >= 0x0001 && c <= 0x007e) || (0xff60 <= c && c <= 0xff9f)) {
                len++;
            }
            else {
                len += 2;
            }
        }
        return len;
    }
    //end
});

seajs.use('forget_pwd');
