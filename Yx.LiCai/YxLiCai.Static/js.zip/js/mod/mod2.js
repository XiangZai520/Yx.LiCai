/**
 * description
 * mod2
 *
 */
define(function(require, exports, module) {

    var mod = require("mod/mod1")


    console.log(mod)

});

