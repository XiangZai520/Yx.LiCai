/*!
 * @description:Register
 * @author:Eilvein
 * @version:V1.0.0
 * @update:2015/5/30
 */

define('reg',['jquery','gxdialog','fastclick','swipe','gxtabs'],function(require, exports, module) {

	var $ = jQuery = require("jquery");//jquery库
	var FastClick = require("fastclick");
	var gxdialog = require("gxdialog");
	var Swipe = require('swipe');
	var gxtabs = require('gxtabs');

	//FastClick.attach(document.body);

	// 验证超时提示
	$.gxDialog.defaults.background = '#000';
	//gxOvertime();
	function gxOvertime() {
		$.gxDialog({
			title: '',
			info: '<div class="pop-box"><p>验证码超时，请重新发送<p><div><button type="submit" class="ui-btn">确认</button></div></div>'
		});
	}



});

seajs.use('reg');
