/*!
 * @description:product
 * @author:Leo
 * @version:V1.0.0
 * @update:2015/6/10
 */

define('yixiu', ['jquery', 'gxdialog', 'fastclick', 'swipe', 'gxtabs'], function (require, exports, module) {

    var $ = jQuery = require("jquery");//jquery库
    var FastClick = require("fastclick");
    var gxdialog = require("gxdialog");
    var Swipe = require('swipe');
    var gxtabs = require('gxtabs');

    // 月份点击Tabs
    $('.J_gxtabs').gxTabs({
        tabList: ".J_gxtabs_nav>ul>li",            //标题列表
        tabContent: ".J_gxtabs_container .J_gxtabs_item",  //内容列表
        tabOn: "active",                		// 菜单划过的类名
        action: "click",                      // click || mouseover
        afterChange: function (tabId) {
            if (typeof ($("#purchasedAmount")) == "undefined")
                return;
            if (tabId == "0") {
                //3个月
                $("#purchasedAmount").val($("#q3_MemberSum").val());
                $("#yiledBase").html($("#q3_YieldBase").val() + "<em>%</em>");
            }
            else {
                //6个月产品
                $("#purchasedAmount").val($("#q6_MemberSum").val());
                $("#yiledBase").html($("#q6_YieldBase").val() + "<em>%</em>");
            }
        }
    });

    //用户当前浏览页面 产品id和类别
    function getProductIDAndCategory() {
        var categoryName = $(".current").children().html(),
          category = 1,
          id = "";
        if (categoryName == "月月盈") {
            id = $("#id_" + category).val();
        }
        else if (categoryName == "季季享") {
            category = parseInt($(".active").html()) == 3 ? 2 : 3;
            id = $("#id_" + category).val();
        }

        return { id: id, category: category };
    }

    //买入按钮
    $(".buy").bind("click", function (e) {
        var product = getProductIDAndCategory(),
            id = product.id,
            category = product.category;

        window.top.location.href = "/buy/buyproduct?ptype=" + category + "&productId=" + id;
    });

    /*!
     * 移动端选项卡
     * @class touchTabs
     *
     */
    touchTabs();
    function touchTabs() {
        var elTabs = document.getElementById('tab-box');
        var pagination = document.getElementById('tab-pagination').getElementsByTagName('li');

        window.tabs = new Swipe(elTabs, {
            callback: function (index) {
                setTab(pagination[index]);
            }
        });

        for (var i = 0; i < pagination.length; i++) {
            var _el = pagination[i];
            _el.setAttribute('data-tab', i);
            _el.onclick = function (e) {
                e.preventDefault();
                setTab(this);
                tabs.slide(parseInt(this.getAttribute('data-tab'), 10), 300);
            };
        }

        function setTab(elem) {
            for (var i = 0; i < pagination.length; i++) {
                pagination[i].className = pagination[i].className.replace('current', ' ');
            }
            elem.className += 'current';
        }
    }

    //首页 产品详情 跳转到 Prduct/Index 
    //初始化页面，显示选中的产品
    (function () {
        var pID = $("#proID").val(); //Home/Index传值： 产品id
        if (pID == "" || pID == null)
            return;

        if (pID == 1) {
            //月月赢
            tabs.slide(0);
        }
        else if (pID == 2 || pID == 3) {
            //季季享
            tabs.slide(1);
            $(".nav-season").children().removeClass("active");
            $(".J_gxtabs_container").children().hide();
            if (pID == 2) {
                //3个月
                $(".nav-season").children("li").eq(0).addClass("active");
            }
            else if (pID == 3) {
                //6个月
                $(".nav-season").children("li").eq(1).addClass("active");
            }
            quarterSelected(pID)
        }
        else if (pID == 4) {
            //年年丰        
            tabs.slide(2);
        }
    })();
    //季季享 3个月/6个月选中事件
    function quarterSelected(id) {
        if (id == 2) { //3个月
            $(".J_gxtabs_container").children("div").eq(0).show();
        }
        else if (id == 3) { //6个月          
            $(".J_gxtabs_container").children("div").eq(1).show();
        }
    }
});

seajs.use('yixiu');
